$(function(){

	$('.dropdown-menu').click(function(e) {
        e.stopPropagation();
    });

    $('#myCarousel').carousel({
	  interval: 5000
	})

		 

})